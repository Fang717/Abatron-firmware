/*************************************************************************
|  COPYRIGHT (c) 2000 BY ABATRON AG
|*************************************************************************
|
|  PROJECT NAME: bdiWind
|  FILENAME    : wdbFslipPktDrv.c
|
|  COMPILER    : Tornado 2
|
|  TARGET OS   : VxWorks
|  TARGET HW   : MPC8260
|
|  PROGRAMMER  : Abatron / RD
|  CREATION    : 6. February 2000
|
|*************************************************************************
|
|  DESCRIPTION :
|  This modul implements a fast SLIP UDP-Lite paket driver. 
|
|  Important: Check use of Dual Port RAM for possible overlaps
|
|*************************************************************************
|
|
|  UPDATES     :
|
|  DATE      NAME  CHANGES
|  -----------------------------------------------------------
|  Latest update
|  ...
|  13.13.97  aba   Bla bla ...
|  ...
|  First update
|
|*************************************************************************/


/*************************************************************************
|  INCLUDES
|*************************************************************************/

#include "string.h"
#include "vxWorks.h"
#include "config.h"
#include "drv/sio/m8260Scc.h"
#include "drv/sio/m8260Sio.h"
#include "drv/sio/m8260Cp.h"
#include "drv/parallel/m8260IOPort.h"
#include "drv/sio/m8260Brg.h"
#include "drv/intrCtl/m8260IntrCtl.h"
#include "wdb/wdbMbufLib.h"
#include "wdbFslipPktDrv.h"

/*************************************************************************
|  DEFINES
|*************************************************************************/

/* SLIP special codes */
#define SLIP_END        0300
#define SLIP_ESC        0333
#define SLIP_ESC_END    0334
#define SLIP_ESC_ESC    0335

#define SCC_NUM                 3	/* !!! update also port configuration !!! */

#define SCC_RBD_NUM		2	/* number of receive  buffers */
#define SCC_TBD_NUM		2	/* number of transmit buffers */
#define SCC_RBD_OFF		0x400
#define SCC_TBD_OFF		(SCC_RBD_OFF + (SCC_RBD_NUM * 8))

#define SCC_RX_BUFF_SIZE        96      /* the size of a receive  buffer */
#define SCC_TX_BUFF_SIZE        96      /* the size of a transmit buffer */

#define SCC_RX_BUF_OFF		0x480	/* allocated in dual port RAM */
#define SCC_TX_BUF_OFF		(SCC_RX_BUF_OFF + (SCC_RBD_NUM * SCC_RX_BUFF_SIZE))

#define STATE_BUSY	1	/* I/O is being performed */
#define STATE_ESC	2	/* in the middle of a SLIP escape seq */


/*************************************************************************
|  MACROS
|*************************************************************************/

#define MIN min

/*************************************************************************
|  TYPEDEFS
|*************************************************************************/

typedef struct          /* SCC_UART_BD */
    {
    VUINT16	statusMode;             /* status and control */
    VINT16      dataLength;             /* length of data buffer in bytes */
    u_char *    dataPointer;            /* points to data buffer */
    } SCC_UART_BD;

typedef struct          /* SCC_UART_DEV */
    {
    int 		sccNum;		/* number of SCC device */
    int 		txBdNum;	/* number of transmit buf descriptors */
    int 		rxBdNum;	/* number of receive buf descriptors */
    SCC_UART_BD * 	txBdBase;	/* transmit BD base address */
    SCC_UART_BD * 	rxBdBase;	/* receive BD base address */
    u_char * 		txBufBase;	/* transmit buffer base address */
    u_char *		rxBufBase;	/* receive buffer base address */
    VINT32 		txBufSize;	/* transmit buffer size */
    VINT32 		rxBufSize;	/* receive buffer size */
    int			txBdNext;	/* next transmit BD to fill */
    int			rxBdNext;	/* next receive BD to read */
    } SCC_UART_DEV;

typedef struct scc_chan {
  UINT32        immrVal;                /* Internal Memory Map Register */
  VINT16       *pSCCE;			/* points to SCCE register */
  SCC_UART_DEV  uart;
} SCC_CHAN;

typedef struct {
  UINT32	state;				/* processing state */
  u_char*	pNext;				/* where to store next char */
  u_char        data[WDB_FSLIP_PKT_MTU];	/* RPC frame buffer */
} RX_FRAME;

typedef struct {
  UINT32	length;				/* remaining bytes to send */
  u_char*	pNext;				/* where to read next char */
  u_char	data[2 * WDB_FSLIP_PKT_MTU];	/* SLIP coded TX frame */
} TX_FRAME;


/*************************************************************************
|  LOCALS
|*************************************************************************/

static SCC_CHAN	        sccChan;        /* info about the SCC channel */
static TX_FRAME         txFrame;
static RX_FRAME		rxFrame;


/* forward declarations */
static STATUS wdbPktPoll (void *pDev);
static STATUS wdbPktTx   (void *pDev, struct mbuf * pMbuf);
static STATUS wdbPktModeSet (void *pDev, uint_t newMode);
static void   wdbPktFree (void *pDev);


/*******************************************************************************
*
* sccInit - initialize the SCC
*/

static void sccInit(void)
{
  UINT32  immrVal;
  UINT8   scc;
  UINT32  clockDivider;
  int     frame;
  UINT32  cpcrVal;

  VINT16 *pSCCM;
  VINT16 *pSCCE;
  VINT32 *pBRGC;
  VINT32 *pGSMR_L;
  VINT32 *pGSMR_H;
  VINT16 *pPSMR;
  VINT16 *pSCC;
  VINT16 *pRBASE;
  VINT16 *pTBASE;
  VINT8  *pRFCR;
  VINT8  *pTFCR;
  VINT16 *pMRBLR;
  VINT16 *pMAXIDL;
  VINT16 *pBRKCR;
  VINT16 *pPAREC;
  VINT16 *pFRMEC;
  VINT16 *pNOSEC;
  VINT16 *pBRKEC;
  VINT16 *pUADDR1;
  VINT16 *pUADDR2;
  VINT16 *pTOSEQ;
  VINT16 *pCHAR1;
  VINT16 *pCHAR2;
  VINT16 *pCHAR3;
  VINT16 *pCHAR4;
  VINT16 *pCHAR5;
  VINT16 *pCHAR6;
  VINT16 *pCHAR7;
  VINT16 *pCHAR8;
  VINT16 *pRCCM;

  /* lock interrupts */
  int oldlevel = intLock ();

  /* setup SCC register pointers */
  immrVal = vxImmrGet();
  scc     = SCC_NUM - 1;

  pBRGC   = (VINT32 *) (immrVal + M8260_BRGC_BASE + (scc * M8260_BRGC_OFFSET_NEXT_BRGC));

  pSCCM   = (VINT16 *) (immrVal + M8260_SCC_BASE + (scc * M8260_SCC_OFFSET_NEXT_SCC) + M8260_SCCM_OFFSET);
  pSCCE   = (VINT16 *) (immrVal + M8260_SCC_BASE + (scc * M8260_SCC_OFFSET_NEXT_SCC) + M8260_SCCE_OFFSET);
  pGSMR_L = (VINT32 *) (immrVal + M8260_SCC_BASE + (scc * M8260_SCC_OFFSET_NEXT_SCC) + M8260_GSMR_L_OFFSET);
  pGSMR_H = (VINT32 *) (immrVal + M8260_SCC_BASE + (scc * M8260_SCC_OFFSET_NEXT_SCC) + M8260_GSMR_H_OFFSET);
  pPSMR   = (VINT16 *) (immrVal + M8260_SCC_BASE + (scc * M8260_SCC_OFFSET_NEXT_SCC) + M8260_PSMR_OFFSET);
  pSCCM   = (VINT16 *) (immrVal + M8260_SCC_BASE + (scc * M8260_SCC_OFFSET_NEXT_SCC) + M8260_SCCM_OFFSET);

  pRBASE  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + M8260_SCC_PRAM_RBASE);
  pTBASE  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + M8260_SCC_PRAM_TBASE);
  pRFCR   = (VINT8  *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + M8260_SCC_PRAM_RFCR);
  pTFCR   = (VINT8  *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + M8260_SCC_PRAM_TFCR);
  pMRBLR  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + M8260_SCC_PRAM_MRBLR);

  pMAXIDL = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x38);
  pBRKCR  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x3C);
  pPAREC  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x3E);
  pFRMEC  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x40);
  pNOSEC  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x42);
  pBRKEC  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x44);
  pUADDR1 = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x48);
  pUADDR2 = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x4A);
  pTOSEQ  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x4E);
  pCHAR1  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x50);
  pCHAR2  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x52);
  pCHAR3  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x54);
  pCHAR4  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x56);
  pCHAR5  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x58);
  pCHAR6  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x5A);
  pCHAR7  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x5C);
  pCHAR8  = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x5E);
  pRCCM   = (VINT16 *) (immrVal + M8260_SCC_PRAM_BASE + (scc * M8260_SCC_PRAM_OFFSET_NEXT_PRAM) + 0x60);

  /* setup channel info */
  sccChan.immrVal      = immrVal;
  sccChan.pSCCE        = pSCCE;
  sccChan.uart.sccNum  = SCC_NUM;

  /* Disable all interrupts */
  *pSCCM = 0;

  /* configure port D pins for SCC3 */
  *M8260_IOP_PDDIR(immrVal) |=  0x00000080L;   	/* set bit 24 for SCC3 */
  *M8260_IOP_PDDIR(immrVal) &= ~0x00000040L;   	/* clear bit 25 for SCC3 */
  *M8260_IOP_PDPAR(immrVal) |=  0x000000C0L;   	/* set bits 24,25 for SCC3 */
  *M8260_IOP_PDSO(immrVal)  &= ~0x000000C0L; 	/* clear bits 24,25 for SCC3 */
  *M8260_IOP_PDODR(immrVal) &= ~0x000000C0L; 	/* clear bits 24,25 for SCC3 */

  /* reset baud rate generator, wait for reset to clear... */
  *pBRGC |= M8260_BRGC_RST;
  while ((*pBRGC) & M8260_BRGC_RST);

  /* select baudrate: BRGCLK is 10MHz (40MHz * 4 / 16) */
  /* BRGCx.CD:	8260: 		BDI:	*/
  /*	0	625'000		-	*/
  /*	1	312'500		298'000	*/
  /*	2	208'000		208'000	*/
  /*	3	156'000		160'000	*/
  /*	4	125'000		122'000	*/
  /*	5	104'000		104'000	*/
  clockDivider = 2;
  *pBRGC       = (M8260_BRGC_CD_MASK & (clockDivider << 1)) | M8260_BRGC_EN;

  /* set up transmit buffer descriptors */
  sccChan.uart.txBdNum   = SCC_TBD_NUM;
  sccChan.uart.txBufSize = SCC_TX_BUFF_SIZE;
  sccChan.uart.txBdBase  = (SCC_UART_BD*)(immrVal + SCC_TBD_OFF);
  sccChan.uart.txBufBase = (u_char*)(immrVal + SCC_TX_BUF_OFF);
  sccChan.uart.txBdNext  = 0;

  /* initialize each transmit buffer descriptor */
  for (frame = 0; frame < sccChan.uart.txBdNum; frame++) {
    sccChan.uart.txBdBase[frame].statusMode  = M8260_SCC_UART_TX_BD_INT;
    sccChan.uart.txBdBase[frame].dataLength  = 0;
    sccChan.uart.txBdBase[frame].dataPointer = sccChan.uart.txBufBase + (frame * sccChan.uart.txBufSize);
  } /* for */

  /* set the last BD to wrap to the first */
  sccChan.uart.txBdBase[(frame - 1)].statusMode |= M8260_SCC_UART_TX_BD_WRAP;

  /* set up receive buffer descriptors */
  sccChan.uart.rxBdNum   = SCC_RBD_NUM;
  sccChan.uart.rxBufSize = SCC_RX_BUFF_SIZE;
  sccChan.uart.rxBdBase  = (SCC_UART_BD*)(immrVal + SCC_RBD_OFF);
  sccChan.uart.rxBufBase = (u_char*)(immrVal + SCC_RX_BUF_OFF);
  sccChan.uart.rxBdNext  = 0;

  /* initialize each receive buffer descriptor */
  for (frame = 0; frame < sccChan.uart.rxBdNum; frame++) {
    sccChan.uart.rxBdBase[frame].statusMode  = M8260_SCC_UART_RX_BD_EMPTY | M8260_SCC_UART_RX_BD_INT;
    sccChan.uart.rxBdBase[frame].dataLength  = sccChan.uart.rxBufSize;
    sccChan.uart.rxBdBase[frame].dataPointer = sccChan.uart.rxBufBase + (frame * sccChan.uart.rxBufSize);
  } /* for */

  /* set the last BD to wrap to the first */
  sccChan.uart.rxBdBase[(frame - 1)].statusMode |= M8260_SCC_UART_RX_BD_WRAP;

  /* initialize parameter RAM area for this SCC */
  *pRBASE  = SCC_RBD_OFF;
  *pTBASE  = SCC_TBD_OFF;
  *pRFCR   = 0x18;	/* supervisor data access */
  *pTFCR   = 0x18;	/* supervisor data access */
  *pMRBLR  = sccChan.uart.rxBufSize;
  *pMAXIDL = 5;
  *pBRKCR  = 1;
  *pPAREC  = 0;
  *pFRMEC  = 0;
  *pNOSEC  = 0;
  *pBRKEC  = 0;
  *pUADDR1 = 0;
  *pUADDR2 = 0;
  *pTOSEQ  = 0;
  *pCHAR1  = 0x8000;
  *pCHAR2  = 0x8000;
  *pCHAR3  = 0x8000;
  *pCHAR4  = 0x8000;
  *pCHAR5  = 0x8000;
  *pCHAR6  = 0x8000;
  *pCHAR7  = 0x8000;
  *pCHAR8  = 0x8000;
  *pRCCM   = 0xC0FF;

  /* program the three SCC mode registers: gsmrl, gsmrh, and psmr */
  * pGSMR_L = M8260_SCC_GSMRL_RDCR_X16 | M8260_SCC_GSMRL_TDCR_X16 | M8260_SCC_GSMRL_UART;
  * pGSMR_H = M8260_SCC_GSMRH_RFW | M8260_SCC_GSMRH_TFL;
  * pPSMR   = M8260_SCC_UART_PSMR_FLC | M8260_SCC_UART_PSMR_CL_8BIT;

  /* wait until the CP is clear */
  do {
    M8260_SCC_32_RD((M8260_CPCR (immrVal)), cpcrVal);
  } while (cpcrVal & M8260_CPCR_FLG) ;

   /* Tell CP to initialize tx and rx parameters for SCC */
   cpcrVal = (  M8260_CPCR_OP (M8260_CPCR_RT_INIT)
              | M8260_CPCR_SBC (M8260_CPCR_SBC_SCC1 | (scc * 0x1))
              | M8260_CPCR_PAGE (M8260_CPCR_PAGE_SCC1 | (scc * 0x1))
              | M8260_CPCR_FLG);
   M8260_SCC_32_WR (M8260_CPCR (immrVal), cpcrVal);

  /* clear all events */
  *pSCCE = M8260_SCC_UART_SCCX_ALL_EVENTS; 

  /* enables the transmitter and receiver  */
  *pGSMR_L |= (M8260_SCC_GSMRL_ENT | M8260_SCC_GSMRL_ENR);

  /* unmask interrupt (Tx, Rx only) */
  *pSCCM |= (M8260_SCC_UART_SCCX_RX | M8260_SCC_UART_SCCX_TX);

  /* enable SCC interrupts at the SIU Interrupt Controller */
  if      (SCC_NUM == 1) m8260IntEnable(INUM_SCC1);
  else if (SCC_NUM == 2) m8260IntEnable(INUM_SCC2);
  else if (SCC_NUM == 3) m8260IntEnable(INUM_SCC3);
  else if (SCC_NUM == 4) m8260IntEnable(INUM_SCC4);

  intUnlock (oldlevel);	/* UNLOCK INTERRUPTS */
} /* sccInit */


/*******************************************************************************
*
* sccInterrupt - handle an SCC interrupt
*
* This routine is called to handle SCC interrupts.
*/

static void sccInterrupt(WDB_FSLIP_PKT_DEV *pPktDev)
{
  UINT16        sccEvent;
  UINT16        rxCount;
  FAST char*	pChar;
  FAST char     rxChar;
  SCC_UART_BD*  pBD;


  /* read and clear events */
  sccEvent = *sccChan.pSCCE;
  *sccChan.pSCCE = sccEvent;

  /* handle receive event */
  if (sccEvent & M8260_SCC_UART_SCCX_RX) {

    /* process all filled receive buffers */
    pBD = sccChan.uart.rxBdBase + sccChan.uart.rxBdNext;
    while (!(pBD->statusMode & M8260_SCC_UART_RX_BD_EMPTY)) {

      /* append to frame buffer */
      if ((rxFrame.state & STATE_BUSY) == 0) {
        rxCount = pBD->dataLength;
        pChar   = pBD->dataPointer;
        while (rxCount--) {
          rxChar = *pChar++;

          if (rxChar == SLIP_END) {
            if (rxFrame.pNext > rxFrame.data) {
              struct mbuf* pMbuf = wdbMbufAlloc();;
              if (pMbuf) {
                wdbMbufClusterInit (pMbuf,
                                    rxFrame.data,
                                    rxFrame.pNext - rxFrame.data,
				    (int (*)())wdbPktFree,
                                    (int)pPktDev);
	        (*pPktDev->wdbDrvIf.stackRcv) (pMbuf);  /* invoke callback */
                rxFrame.state |= STATE_BUSY;
              } /* if */
              else {
                rxFrame.state = 0;
                rxFrame.pNext = rxFrame.data;
              } /* else */
              break;
            } /* if */
          } /* if */

          else if (rxChar == SLIP_ESC) {
            rxFrame.state |= STATE_ESC;
          } /* else if */

          else {
            /* check overflow */
            if ((rxFrame.pNext - rxFrame.data) >= WDB_FSLIP_PKT_MTU) {
              rxFrame.state = 0;
              rxFrame.pNext = rxFrame.data;
              break;
            } /* if */
            if (rxFrame.state & STATE_ESC) {
              rxFrame.state &= (~STATE_ESC);
              if      (rxChar == SLIP_ESC_END) *rxFrame.pNext++ = SLIP_END;
              else if (rxChar == SLIP_ESC_ESC) *rxFrame.pNext++ = SLIP_ESC;
            } /* if */
            else {
              *rxFrame.pNext++ = rxChar;
            } /* else */
          } /* else */

        } /* while */
      } /* if */

      /* switch to next buffer */
      pBD->statusMode |= M8260_SCC_UART_RX_BD_EMPTY;
      sccChan.uart.rxBdNext = (sccChan.uart.rxBdNext + 1) % sccChan.uart.rxBdNum;
      pBD = sccChan.uart.rxBdBase + sccChan.uart.rxBdNext;

    } /* while */
  } /* if */

  /* handle transmit event */
  if ((sccEvent & M8260_SCC_UART_SCCX_TX) && (txFrame.length > 0)) {

    /* process all empty transmit buffers */
    pBD = sccChan.uart.txBdBase + sccChan.uart.txBdNext;
    while (!(pBD->statusMode & M8260_SCC_UART_TX_BD_READY) && (txFrame.length > 0)) {

      pBD->dataLength = 0;
      pChar = pBD->dataPointer;
      while ((pBD->dataLength < sccChan.uart.txBufSize) && (txFrame.length > 0)) {
        *pChar++ = *txFrame.pNext++;
        pBD->dataLength++;
        txFrame.length--;
      } /* while */

      /* switch to next buffer */
      pBD->statusMode |= M8260_SCC_UART_TX_BD_READY;
      sccChan.uart.txBdNext = (sccChan.uart.txBdNext + 1) % sccChan.uart.txBdNum;
      pBD = sccChan.uart.txBdBase + sccChan.uart.txBdNext;

    } /* while */
  } /* if */

} /* sccInterrupt */


/*******************************************************************************
*
* wdbFslipPktDevInit - init the fast SLIP paket driver
*
* This routine init the WDB agents paket driver.
*
* RETURNS: initialized WDB_SLIP_PKT_DEV structure
*
*/
void wdbFslipPktDevInit
    (
    WDB_FSLIP_PKT_DEV *pPktDev,
    void             (*stackRcv)()
    )
{
  VOIDFUNCPTR*	ivec;

  /* setup driver interface structure */
  pPktDev->wdbDrvIf.mode       = WDB_COMM_MODE_INT;
  pPktDev->wdbDrvIf.mtu        = WDB_FSLIP_PKT_MTU;
  pPktDev->wdbDrvIf.stackRcv   = stackRcv;
  pPktDev->wdbDrvIf.devId      = (WDB_FSLIP_PKT_DEV *)pPktDev;
  pPktDev->wdbDrvIf.pollRtn    = wdbPktPoll;
  pPktDev->wdbDrvIf.pktTxRtn   = wdbPktTx;
  pPktDev->wdbDrvIf.modeSetRtn = wdbPktModeSet;

  /* init receive frame */
  rxFrame.state = 0;
  rxFrame.pNext = rxFrame.data;

  /* init transmit frame */
  txFrame.length = 0;
  txFrame.pNext  = txFrame.data;

  /* init SCC channel in CPM */
  sccInit();

  /* connect interrupt service */
  if      (SCC_NUM == 1) ivec = INUM_TO_IVEC(INUM_SCC1);
  else if (SCC_NUM == 2) ivec = INUM_TO_IVEC(INUM_SCC2);
  else if (SCC_NUM == 3) ivec = INUM_TO_IVEC(INUM_SCC3);
  else if (SCC_NUM == 4) ivec = INUM_TO_IVEC(INUM_SCC4);
  (void)intConnect (ivec, (VOIDFUNCPTR) sccInterrupt, (int)pPktDev);
} /* wdbFslipPktDevInit */


/******************************************************************************
*
* wdbPktTx - transmit a packet
*
* This routine can only be called by the WDB agent.
*
* RETURNS: OK, or ERROR if a packet is currently being transmitted, or
* the packet is too large to send.
*/

static STATUS wdbPktTx
    (
    void * pDev,
    struct mbuf * pMbuf
    )
{
  int		pktSize;
  u_char        txChar;
  SCC_UART_BD*  pTxBD;
  u_char*       pPkt;
  u_char*       pBuf;

  static u_char pktBuf[WDB_FSLIP_PKT_MTU];

  /* check if buffer free */
  if (txFrame.length > 0) return (ERROR);

  /* copy transmit data to local buffer */
  wdbMbufDataGet(pMbuf, pktBuf, WDB_FSLIP_PKT_MTU, &pktSize);
  wdbMbufChainFree(pMbuf);

  /* build SLIP frame */
  pPkt = pktBuf;
  pBuf = txFrame.data;
  while (pktSize--) {
    txChar = *pPkt++;
    if (txChar == SLIP_END) {
      *pBuf++ = SLIP_ESC;
      *pBuf++ = SLIP_ESC_END;
    } /* if */
    else if (txChar == SLIP_ESC) {
      *pBuf++ = SLIP_ESC;
      *pBuf++ = SLIP_ESC_ESC;
    } /* else if */
    else {
      *pBuf++ = txChar;
    } /* else */
  } /* while */
  *pBuf++ = SLIP_END;  /* mark end of frame */
  txFrame.length = pBuf - txFrame.data;
  txFrame.pNext  = txFrame.data;

  /* start transmitting (send SLIP_END) */
  pTxBD = sccChan.uart.txBdBase + sccChan.uart.txBdNext;
  if (pTxBD->statusMode & M8260_SCC_UART_TX_BD_READY) return (ERROR);
  *pTxBD->dataPointer = SLIP_END;
  pTxBD->dataLength   = 1;
  sccChan.uart.txBdNext = (sccChan.uart.txBdNext + 1) % sccChan.uart.txBdNum;
  pTxBD->statusMode  |= M8260_SCC_UART_TX_BD_READY;

  return (OK);
} /* wdbPktTx */


/******************************************************************************
*
* wdbPktFree - free the input buffer
*
* This is the callback used to let us know the agent is done with the
* input buffer we loaded it.
*
* RETURNS: N/A
*/

static void wdbPktFree
    (
    void *	pDev
    )
    {

    rxFrame.state = 0;
    rxFrame.pNext = rxFrame.data;

    }

/******************************************************************************
*
* wdbPktModeSet - switch driver modes
*
* RETURNS: OK for a supported mode, else ERROR
*/

static STATUS wdbPktModeSet
    (
    void *	pDev,
    uint_t	newMode
    )
    {
    WDB_FSLIP_PKT_DEV * pPktDev = pDev;

    if (newMode == WDB_COMM_MODE_INT)
	pPktDev->wdbDrvIf.mode = WDB_COMM_MODE_INT;
    else if (newMode == WDB_COMM_MODE_POLL)
	pPktDev->wdbDrvIf.mode = WDB_COMM_MODE_POLL;
    else
	return (ERROR);

    return (OK);
    }

/******************************************************************************
*
* wdbPktPoll - poll for a packet
*
* This routine polls for a packet. If a packet has arrived it invokes
* the agents callback.
*
* RETURNS: OK if a packet has arrived, else ERROR.
*/

static STATUS wdbPktPoll
    (
    void *	pDev
    )
    {
    WDB_FSLIP_PKT_DEV *	pPktDev = pDev;
    struct mbuf * 	pMbuf;

    return (ERROR);
    }



