/* wdbFslip.c - WDB fast SLIP communication initialization library */

/* Copyright 1999 Abatron AG. */

/*
modification history
--------------------

01a,17jun99,rd   written
*/

/*
DESCRIPTION
Initializes the fast SLIP connection for the WDB agent.

NOMANUAL
*/

#include "wdbFslipPktDrv.c"

#if     WDB_MTU > WDB_FSLIP_PKT_MTU
#undef  WDB_MTU
#define WDB_MTU WDB_FSLIP_PKT_MTU
#endif  /* WDB_MTU > WDB_FSLIP_PKT_MTU */

/******************************************************************************
*
* wdbCommDevInit - initialize the fast SLIP connection
*/

STATUS wdbCommDevInit
    (
    WDB_COMM_IF *	pCommIf,
    char ** 		ppWdbInBuf,
    char **		ppWdbOutBuf
    )
    {
    static WDB_FSLIP_PKT_DEV	wdbFslipPktDev;
    static uint_t		wdbInBuf [WDB_MTU/4];
    static uint_t		wdbOutBuf [WDB_MTU/4];

    /* update input & output buffer pointers */
    *ppWdbInBuf  = (char *) wdbInBuf;
    *ppWdbOutBuf = (char *) wdbOutBuf;

    /* update communication interface mtu */
    wdbCommMtu = WDB_MTU;

    /* FSLIP packet driver */
    wdbFslipPktDevInit (&wdbFslipPktDev, udpRcv);

    if (udpCommIfInit (pCommIf, &wdbFslipPktDev.wdbDrvIf) == ERROR)
	return (ERROR);

    return (OK);
    }
