/* wdbHdlcPktDrv.h - header file for debug agents HDLC packet driver */

/* Copyright 1995-2000 Abatron AG, Switzerland. */

/*
modification history
--------------------
04jan00/RD:  created.
*/

#ifndef __INCwdbHdlcPktDrvh
#define __INCwdbHdlcPktDrvh

/* includes */

#include "wdb/wdb.h"
#include "wdb/wdbCommIfLib.h"
#include "wdb/wdbMbufLib.h"

/* defines */

#define WDB_HDLC_PKT_MTU	1500    /* MTU of this driver */

/* data types */

typedef struct		/* hidden */
    {
    WDB_DRV_IF	wdbDrvIf;	/* a packet dev must have this first   */
    u_int	currMode;	/* current mode    - poll or int       */
    void*       pBD;            /* received buffer descriptor          */
    } WDB_HDLC_PKT_DEV;

/* function prototypes */

#if defined(__STDC__)

extern void	wdbHdlcPktDevInit (WDB_HDLC_PKT_DEV *pPktDev,
				   void             (*stackRcv)());

#else   /* __STDC__ */

extern void    wdbHdlcPktDevInit ();

#endif  /* __STDC__ */

#endif  /* __INCwdbHdlcPktDrvh */

