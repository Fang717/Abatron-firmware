/*************************************************************************
|  COPYRIGHT (c) 2000 BY ABATRON AG
|*************************************************************************
|
|  PROJECT NAME: bdiWind
|  FILENAME    : wdbHdlcPktDrv.c
|
|  COMPILER    : Tornado 2
|
|  TARGET OS   : VxWorks
|  TARGET HW   : MBX860
|
|  PROGRAMMER  : Abatron / RD
|  CREATION    : 22. March 2000
|
|*************************************************************************
|
|  DESCRIPTION :
|  This modul implements a HDLC UDP-Lite paket driver. 
|  
|  Important: Check use of Dual Port RAM for possible overlaps
|
|*************************************************************************
|
|
|  UPDATES     :
|
|  DATE      NAME  CHANGES
|  -----------------------------------------------------------
|  Latest update
|  ...
|  13.13.97  aba   Bla bla ...
|  ...
|  First update
|
|*************************************************************************/

/*************************************************************************
|  INCLUDES
|*************************************************************************/

#include "string.h"
#include "vxWorks.h"
#include "cacheLib.h"
#include "config.h"
#include "drv/multi/ppc860Siu.h"
#include "drv/multi/ppc860Cpm.h"
#include "drv/sio/ppc860Sio.h"
#include "mbx800.h"
#include "wdb/wdbMbufLib.h"
#include "wdbHdlcPktDrv.h"

/*************************************************************************
|  DEFINES
|*************************************************************************/

/* SCC HDLC Protocol Specific Mode Register definitions */

#define SCC_HDLC_PSMR_MFF       0x0008          /* multiple frame fifo */
#define SCC_HDLC_PSMR_BRM       0x0010          /* HDLC bus RTS mode */
#define SCC_HDLC_PSMR_BUS       0x0020          /* HDLC bus mode */
#define SCC_HDLC_PSMR_DRT       0x0040          /* disable Rx while Tx */
#define SCC_HDLC_PSMR_FSE       0x0080          /* flasg sharing enable */
#define SCC_HDLC_PSMR_RTE       0x0200          /* retransmit enable */
#define SCC_HDLC_PSMR_CRC16     0x0000          /* 16bit CCITT-CRC */
#define SCC_HDLC_PSMR_CRC32     0x0800          /* 32bit CCITT-CRC */
#define SCC_HDLC_PSMR_NOF_0     0x0000          /* number of flags */
#define SCC_HDLC_PSMR_NOF_1     0x1000          /* number of flags */
#define SCC_HDLC_PSMR_NOF_2     0x2000          /* number of flags */
#define SCC_HDLC_PSMR_NOF_3     0x3000          /* number of flags */

/* SCC HDLC Event and Mask Register definitions */

#define SCC_HDLC_SCCX_RXB       0x0001          /* buffer received */
#define SCC_HDLC_SCCX_TXB       0x0002          /* buffer transmitted */
#define SCC_HDLC_SCCX_BSY       0x0004          /* busy condition */
#define SCC_HDLC_SCCX_RXF       0x0008          /* frame received */
#define SCC_HDLC_SCCX_TXE       0x0010          /* TX error */
#define SCC_HDLC_SCCX_GRA       0x0080          /* graceful stop complete */
#define SCC_HDLC_SCCX_IDL       0x0100          /* idle sequence stat changed */
#define SCC_HDLC_SCCX_FLG       0x0200          /* flag status */
#define SCC_HDLC_SCCX_DCC       0x0400          /* DPLL CS changed */
#define SCC_HDLC_SCCX_GL_T      0x0800          /* glitch on Tx */
#define SCC_HDLC_SCCX_GL_R      0x1000          /* glitch on Rx */

/* SCC HDLC Receive Buffer Descriptor definitions */

#define SCC_HDLC_RX_BD_CD       0x0001          /* carrier detect loss */
#define SCC_HDLC_RX_BD_OV       0x0002          /* receiver overrun */
#define SCC_HDLC_RX_BD_CR       0x0004          /* CRC error */
#define SCC_HDLC_RX_BD_AB       0x0008          /* abort sequence */
#define SCC_HDLC_RX_BD_NO       0x0010          /* no octed aligned frame */
#define SCC_HDLC_RX_BD_LG       0x0020          /* frame length violation */
#define SCC_HDLC_RX_BD_DE       0x0080          /* DPLL error */
#define SCC_HDLC_RX_BD_CM       0x0200          /* continous mode */
#define SCC_HDLC_RX_BD_F        0x0400          /* first in frame */
#define SCC_HDLC_RX_BD_L        0x0800          /* last in frame */
#define SCC_HDLC_RX_BD_INT      0x1000          /* interrupt generated */
#define SCC_HDLC_RX_BD_WRAP     0x2000          /* wrap back to first BD */
#define SCC_HDLC_RX_BD_EMPTY    0x8000          /* buffer is empty */

/* SCC HDLC Transmit Buffer Descriptor definitions */

#define SCC_HDLC_TX_BD_CT       0x0001          /* cts was lost during tx */
#define SCC_HDLC_TX_BD_UN       0x0002          /* underrun */
#define SCC_HDLC_TX_BD_CM       0x0200          /* continous mode */
#define SCC_HDLC_TX_BD_TC       0x0400          /* TX CRC */
#define SCC_HDLC_TX_BD_L        0x0800          /* last */
#define SCC_HDLC_TX_BD_INT      0x1000          /* interrupt generated */
#define SCC_HDLC_TX_BD_WRAP     0x2000          /* wrap back to first BD */
#define SCC_HDLC_TX_BD_READY    0x8000          /* buffer is being sent */

#define HDLC_RX_ERRORS          0x00BF          /* RX-BD errors */

#define SCC_NUM                 2		/* the used SCC channel */
#define BRG_NUM                 2       	/* the used baudrate generator   */
#define SCC_BAUDRATE		1042000		/* the baudrate to use */

#define SCC_RBD_NUM		2
#define SCC_TBD_NUM		2
#define SCC_RBD_OFF		0x400
#define SCC_TBD_OFF		(SCC_RBD_OFF + (SCC_RBD_NUM * 8))

#define SCC_RX_BUFF_SIZE        (WDB_HDLC_PKT_MTU + 8)	/* the size of a receive buffer  */
#define SCC_TX_BUFF_SIZE        WDB_HDLC_PKT_MTU	/* the size of a transmit buffer */

/* mapped to non cached area */
/*
#define SCC_RX_BUFF_ADDR	0x8000			
#define SCC_TX_BUFF_ADDR	(SCC_RX_BUFF_ADDR + (SCC_RBD_NUM * SCC_RX_BUFF_SIZE))
*/


/*************************************************************************
|  MACROS
|*************************************************************************/

#define MIN min

/*************************************************************************
|  TYPEDEFS
|*************************************************************************/

/* SCC HDLC protocol specific parameters */

typedef struct          /* SCC_HDLC_PROTO */
    {
    VINT16      rbase;	/* 00 Rx buffer descriptor base address */
    VINT16      tbase;	/* 02 Tx buffer descriptor base address */
    VINT8       rfcr;	/* 04 Rx function code */
    VINT8       tfcr;	/* 05 Tx function code */
    VINT16      mrblr;	/* 06 maximum receive buffer length */
    VINT32      rstate;	/* 08 Rx internal state */
    VINT32      res1;	/* 0C Rx internal data pointer */
    VINT16      rbptr;	/* 10 Rx buffer descriptor pointer */
    VINT16      res2;	/* 12 reserved/internal */
    VINT32      res3;	/* 14 reserved/internal */
    VINT32      tstate;	/* 18 Tx internal state */
    VINT32      res4;	/* 1C reserved/internal */
    VINT16      tbptr;	/* 20 Tx buffer descriptor pointer */
    VINT16      res5;	/* 22 reserved/internal */
    VINT32      res6;	/* 24 reserved/internal */
    VINT32	rcrc;	/* 28 temp receive CRC */
    VINT32	tcrc;	/* 2C temp transmit CRC */
    VUINT32     res7;   /* reserved */
    VUINT32     cmask;  /* CRC constant */
    VUINT32     cpres;  /* CRC preset */
    VUINT16     disfc;  /* discard frame counter */
    VUINT16     crcec;  /* CRC error counter */
    VUINT16     abtsc;  /* abort sequence counter */
    VUINT16     nmarc;  /* nonmatching address RX counter */
    VUINT16     retrc;  /* frame transmission counter */
    VUINT16     mflr ;  /* max frame length register */
    VUINT16     maxcnt; /* max length counter */
    VUINT16     rfthr;  /* receive frame threshold */
    VUINT16     rfcnt;  /* receive frame count */
    VUINT16     hmask;  /* frame address mask */
    VUINT16     haddr1; /* frame address */
    VUINT16     haddr2; /* frame address */
    VUINT16     haddr3; /* frame address */
    VUINT16     haddr4; /* frame address */
    VUINT16     tmp;    /* temp storage */
    VUINT16     tmp_mb; /* temp storage */
    } SCC_HDLC;

typedef struct          /* SCC_HDLC_BD */
    {
    VUINT16	statusMode;             /* status and control */
    VINT16      dataLength;             /* length of data buffer in bytes */
    u_char *    dataPointer;            /* points to data buffer */
    } SCC_HDLC_BD;

typedef struct          /* SCC_HDLC_DEV */
    {
    int 		txBdNum;	/* number of transmit buf descriptors */
    int 		rxBdNum;	/* number of receive buf descriptors */
    SCC_HDLC_BD * 	txBdBase;	/* transmit BD base address */
    SCC_HDLC_BD * 	rxBdBase;	/* receive BD base address */
    u_char * 		txBufBase;	/* transmit buffer base address */
    u_char *		rxBufBase;	/* receive buffer base address */
    int			txBdNext;	/* next transmit BD to fill */
    int			rxBdNext;	/* next receive BD to read */
    volatile SCC_HDLC *	pScc;		/* SCC parameter RAM */
    volatile SCC_REG *	pSccReg;	/* SCC registers */
    VINT32		intMask;	/* interrupt acknowledge mask */
    } SCC_HDLC_DEV;

typedef struct scc_chan {
  int                 clockRate;      /* CPU clock frequency (Hz) */
  int                 bgrNum;         /* number of BRG being used */
  VINT32 *            pBaud;          /* BRG registers */
  VINT32              regBase;        /* register/DPR base address */
  SCC_HDLC_DEV        hdlc;
} SCC_CHAN;


/*************************************************************************
|  LOCALS
|*************************************************************************/

static SCC_CHAN	        sccChan;        /* info about the SCC channel */


/*************************************************************************
|  FORWARD DECLARATIONS
|*************************************************************************/

static STATUS wdbPktPoll (void *pDev);
static STATUS wdbPktTx   (void *pDev, struct mbuf * pMbuf);
static STATUS wdbPktModeSet (void *pDev, uint_t newMode);
static void   wdbPktFree (void *pDev);


/*******************************************************************************
*
* sccInit - initialize the SCC
*/

static void sccInit(void)
{
  int           scc;			/* the SCC number being initialized */
  int           baud;			/* the baud rate generator being used */
  int           frame;
  UINT32        clockDivider;

  /* lock interrupts */
  int oldlevel = intLock ();

  scc  = SCC_NUM - 1;		/* get SCC number */
  baud = BRG_NUM - 1;		/* get BRG number */

  /* setup channel info */
  sccChan.clockRate      = SPLL_FREQ_REQUESTED;
  sccChan.regBase        = vxImmrGet();
  sccChan.bgrNum         = BRG_NUM;
  sccChan.hdlc.pScc      = (SCC_HDLC*) ((UINT32)PPC860_DPR_SCC1(MPC860_DPRAM_BASE(sccChan.regBase)) + (scc * 0x100));
  sccChan.hdlc.pSccReg   = (SCC_REG*)((UINT32)MPC860_GSMR_L1(sccChan.regBase) + (scc * 0x20));
  sccChan.hdlc.intMask   = CIMR_SCC1 >> scc;

  sccChan.pBaud = (UINT32*)((UINT32)MPC860_BRGC1(sccChan.regBase) + (scc * 4));

  /* Disable all interrupts */
  sccChan.hdlc.pSccReg->sccm = 0;

  /* select Rx/TX pins */
  *PAPAR(sccChan.regBase) |= 0x03 << (scc * 2);

  /* set it to normal operations */
  *MPC860_SDCR(sccChan.regBase) = SDCR_RAID_BR5;

  /* masks off this SMC's interrupt. */
  *CIMR(sccChan.regBase) &= (~sccChan.hdlc.intMask);

  /* set up SCC as NMSI, select Baud Rate Generator */
  switch( baud ) {
    default:	/* default to BRG1 */
    case 0:
      * SICR(sccChan.regBase) |= ((SICR_T1CS_BRG1 | SICR_R1CS_BRG1) << (8 * scc));
      break;
    case 1:
      * SICR(sccChan.regBase) |= ((SICR_T1CS_BRG2 | SICR_R1CS_BRG2) << (8 * scc));
      break;
    case 2:
      * SICR(sccChan.regBase) |= ((SICR_T1CS_BRG3 | SICR_R1CS_BRG3) << (8 * scc));
      break;
    case 3:
      * SICR(sccChan.regBase) |= ((SICR_T1CS_BRG4 | SICR_R1CS_BRG4) << (8 * scc));
      break;
  } /* switch */

  /* reset baud rate generator, wait for reset to clear... */
  *sccChan.pBaud |= BRGC_RST;
  while (*sccChan.pBaud & BRGC_RST);

  /* set baudrate */
  clockDivider   = ((sccChan.clockRate + (8 * SCC_BAUDRATE)) / (16L * SCC_BAUDRATE)) - 1;
  *sccChan.pBaud = (BRGC_CD_MSK & (clockDivider << 1)) | BRGC_EN;

  /* set up transmit buffer descriptors */
  sccChan.hdlc.txBdNum   = SCC_TBD_NUM;
  sccChan.hdlc.txBdBase  = (SCC_HDLC_BD*)(sccChan.regBase + MPC860_REGB_OFFSET + SCC_TBD_OFF);
  sccChan.hdlc.txBufBase = (u_char*)cacheDmaMalloc(SCC_TBD_NUM * SCC_TX_BUFF_SIZE);
  /* sccChan.hdlc.txBufBase = (u_char*)(SCC_TX_BUFF_ADDR); */
  sccChan.hdlc.txBdNext  = 0;

  /* initialize each transmit buffer descriptor */
  for (frame = 0; frame < sccChan.hdlc.txBdNum; frame++) {
    sccChan.hdlc.txBdBase[frame].statusMode  = SCC_HDLC_TX_BD_L | SCC_HDLC_TX_BD_TC;
    sccChan.hdlc.txBdBase[frame].dataLength  = 0;
    sccChan.hdlc.txBdBase[frame].dataPointer = sccChan.hdlc.txBufBase + (frame * SCC_TX_BUFF_SIZE);
  } /* for */

  /* set the last BD to wrap to the first */
  sccChan.hdlc.txBdBase[(frame - 1)].statusMode |= SCC_HDLC_TX_BD_WRAP;

  /* set up receive buffer descriptors */
  sccChan.hdlc.rxBdNum   = SCC_RBD_NUM;
  sccChan.hdlc.rxBdBase  = (SCC_HDLC_BD*)(sccChan.regBase + MPC860_REGB_OFFSET + SCC_RBD_OFF);
  sccChan.hdlc.rxBufBase = (u_char*)cacheDmaMalloc(SCC_RBD_NUM * SCC_RX_BUFF_SIZE);
  /* sccChan.hdlc.rxBufBase = (u_char*)(SCC_RX_BUFF_ADDR); */
  sccChan.hdlc.rxBdNext  = 0;

  /* initialize each receive buffer descriptor */
  for (frame = 0; frame < sccChan.hdlc.rxBdNum; frame++) {
    sccChan.hdlc.rxBdBase[frame].statusMode  = SCC_HDLC_RX_BD_EMPTY | SCC_HDLC_RX_BD_INT;
    sccChan.hdlc.rxBdBase[frame].dataLength  = SCC_RX_BUFF_SIZE;
    sccChan.hdlc.rxBdBase[frame].dataPointer = sccChan.hdlc.rxBufBase + (frame * SCC_RX_BUFF_SIZE);
  } /* for */

  /* set the last BD to wrap to the first */
  sccChan.hdlc.rxBdBase[(frame - 1)].statusMode |= SCC_HDLC_RX_BD_WRAP;

  /* initialize parameter RAM area for this SCC */
  sccChan.hdlc.pScc->rbase  = SCC_RBD_OFF;
  sccChan.hdlc.pScc->tbase  = SCC_TBD_OFF;
  sccChan.hdlc.pScc->rfcr   = 0x18;	/* supervisor data access */
  sccChan.hdlc.pScc->tfcr   = 0x18;	/* supervisor data access */
  sccChan.hdlc.pScc->mrblr  = SCC_RX_BUFF_SIZE;


  sccChan.hdlc.pScc->cmask  = 0x0000F0B8;
  sccChan.hdlc.pScc->cpres  = 0x0000FFFF;
  sccChan.hdlc.pScc->disfc  = 0;
  sccChan.hdlc.pScc->crcec  = 0;
  sccChan.hdlc.pScc->abtsc  = 0;
  sccChan.hdlc.pScc->nmarc  = 0;
  sccChan.hdlc.pScc->retrc  = 0;
  sccChan.hdlc.pScc->mflr   = SCC_RX_BUFF_SIZE;
  sccChan.hdlc.pScc->rfthr  = 1;
  sccChan.hdlc.pScc->hmask  = 0x0000;
  sccChan.hdlc.pScc->haddr1 = 0x0000;
  sccChan.hdlc.pScc->haddr2 = 0x0000;
  sccChan.hdlc.pScc->haddr3 = 0x0000;
  sccChan.hdlc.pScc->haddr4 = 0x0000;

  /* program the three SCC mode registers: gsmrl, gsmrh, and psmr */
  sccChan.hdlc.pSccReg->gsmrl =   SCC_GSMRL_TPL_16
                                | SCC_GSMRL_TPP_01
                                | SCC_GSMRL_TDCR_X16
                                | SCC_GSMRL_RDCR_X16
                                | (4L<<11) | (4L<<8)     /* Manchester encoding */
                                | SCC_GSMRL_HDLC;;
  sccChan.hdlc.pSccReg->gsmrh = 0;
  sccChan.hdlc.pSccReg->psmr  = SCC_HDLC_PSMR_NOF_0 | SCC_HDLC_PSMR_CRC16;

  /* execute INIT RX and TX PARAMS */
  while (*CPCR(sccChan.regBase) & CPM_CR_FLG);
  switch( SCC_NUM ) {
    case 0:
      *CPCR(sccChan.regBase) = CPM_CR_CHANNEL_SCC1 | CPM_CR_SCC_INIT_RT | CPM_CR_FLG;
      break;
    case 1:
      *CPCR(sccChan.regBase) = CPM_CR_CHANNEL_SCC2 | CPM_CR_SCC_INIT_RT | CPM_CR_FLG;
      break;
    case 2:
      *CPCR(sccChan.regBase) = CPM_CR_CHANNEL_SCC3 | CPM_CR_SCC_INIT_RT | CPM_CR_FLG;
      break;
    case 3:
      *CPCR(sccChan.regBase) = CPM_CR_CHANNEL_SCC4 | CPM_CR_SCC_INIT_RT | CPM_CR_FLG;
      break;
  } /* switch */
  while (*CPCR(sccChan.regBase) & CPM_CR_FLG);

  /* clear all events */
  sccChan.hdlc.pSccReg->scce = 0xFFFF; 

  /* enables the transmitter and receiver  */
  sccChan.hdlc.pSccReg->gsmrl |= (SCC_GSMRL_ENT | SCC_GSMRL_ENR);

  /* unmask interrupt */
  sccChan.hdlc.pSccReg->sccm |= SCC_HDLC_SCCX_RXF;
  *CIMR(sccChan.regBase) |= sccChan.hdlc.intMask;

  intUnlock (oldlevel);	/* UNLOCK INTERRUPTS */
} /* sccInit */


/*******************************************************************************
*
* sccInterrupt - handle an SCC interrupt
*
* This routine is called to handle SCC interrupts.
*/

static void sccInterrupt(WDB_HDLC_PKT_DEV *pPktDev)
{
  UINT16        sccEvent;
  UINT16        rxCount;
  FAST char*	pChar;
  FAST char     rxChar;
  SCC_HDLC_BD*  pBD;


  /* read and clear events */
  sccEvent = sccChan.hdlc.pSccReg->scce;
  sccChan.hdlc.pSccReg->scce = sccEvent;

  /* handle receive event */
  if (sccEvent & SCC_HDLC_SCCX_RXF) {

    /* process all filled receive buffers */
    pBD = sccChan.hdlc.rxBdBase + sccChan.hdlc.rxBdNext;
    while (    ((pBD->statusMode & SCC_HDLC_RX_BD_EMPTY) == 0)
            && ((pBD->statusMode & SCC_HDLC_RX_BD_INT)   != 0)
          ) {

      /* a valid receive frame */
      if ((pBD->statusMode & HDLC_RX_ERRORS) == 0) {
        struct mbuf* pMbuf = wdbMbufAlloc();;
        if (pMbuf) {
          pBD->statusMode &= ~SCC_HDLC_RX_BD_INT;
          pPktDev->pBD = (void*)pBD;
          CACHE_DMA_INVALIDATE(pBD->dataPointer, SCC_RX_BUFF_SIZE);
          wdbMbufClusterInit (pMbuf,
                              pBD->dataPointer,
                              (pBD->dataLength - 2), /* discard CRC */
		              (int (*)())wdbPktFree,
                              (int)pPktDev);
	  (*pPktDev->wdbDrvIf.stackRcv) (pMbuf);  /* invoke callback */
        } /* if */
      } /* if */

      /* discard frame and release buffer */
      if (pBD->statusMode & SCC_HDLC_RX_BD_INT) {
        pBD->dataLength  = 0;
        pBD->statusMode &= SCC_HDLC_RX_BD_WRAP;
        pBD->statusMode |= (SCC_HDLC_RX_BD_EMPTY | SCC_HDLC_RX_BD_INT);
      } /* else */

      /* switch to next buffer */
      pBD->statusMode |= SCC_HDLC_RX_BD_EMPTY;
      sccChan.hdlc.rxBdNext = (sccChan.hdlc.rxBdNext + 1) % sccChan.hdlc.rxBdNum;
      pBD = sccChan.hdlc.rxBdBase + sccChan.hdlc.rxBdNext;

    } /* while */
  } /* if */

} /* sccInterrupt */


/*******************************************************************************
*
* wdbHdlcPktDevInit - init the fast SLIP paket driver
*
* This routine init the WDB agents paket driver.
*
* RETURNS: initialized WDB_SLIP_PKT_DEV structure
*
*/
void wdbHdlcPktDevInit
    (
    WDB_HDLC_PKT_DEV *pPktDev,
    void             (*stackRcv)()
    )
{
  VOIDFUNCPTR*	ivec;

  /* setup driver interface structure */
  pPktDev->wdbDrvIf.mode       = WDB_COMM_MODE_INT;
  pPktDev->wdbDrvIf.mtu        = WDB_HDLC_PKT_MTU;
  pPktDev->wdbDrvIf.stackRcv   = stackRcv;
  pPktDev->wdbDrvIf.devId      = (WDB_HDLC_PKT_DEV *)pPktDev;
  pPktDev->wdbDrvIf.pollRtn    = wdbPktPoll;
  pPktDev->wdbDrvIf.pktTxRtn   = wdbPktTx;
  pPktDev->wdbDrvIf.modeSetRtn = wdbPktModeSet;

  /* init SCC channel in CPM */
  sccInit();

  /* connect interrupt service */
  if      (SCC_NUM == 1) ivec = IV_SCC1;
  else if (SCC_NUM == 2) ivec = IV_SCC2;
  else if (SCC_NUM == 3) ivec = IV_SCC3;
  else if (SCC_NUM == 4) ivec = IV_SCC4;
  (void)intConnect (ivec, (VOIDFUNCPTR) sccInterrupt, (int)pPktDev);
} /* wdbHdlcPktDevInit */


/******************************************************************************
*
* wdbPktTx - transmit a packet
*
* This routine can only be called by the WDB agent.
*
* RETURNS: OK, or ERROR if a packet is currently being transmitted, or
* the packet is too large to send.
*/

static STATUS wdbPktTx
    (
    void * pDev,
    struct mbuf * pMbuf
    )
{
  int		pktSize;
  u_char        txChar;
  SCC_HDLC_BD*  pTxBD;

  /* copy transmit data to local buffer */
  pTxBD = sccChan.hdlc.txBdBase + sccChan.hdlc.txBdNext;
  if (pTxBD->statusMode & SCC_HDLC_TX_BD_READY) return (ERROR);
  wdbMbufDataGet(pMbuf, pTxBD->dataPointer, WDB_HDLC_PKT_MTU, &pktSize);
  wdbMbufChainFree(pMbuf);

  /* flush cache for the used buffer */
  CACHE_DMA_FLUSH(pTxBD->dataPointer, SCC_TX_BUFF_SIZE);

  /* start transmitting */
  pTxBD->dataLength = pktSize;
  sccChan.hdlc.txBdNext = (sccChan.hdlc.txBdNext + 1) % sccChan.hdlc.txBdNum;
  pTxBD->statusMode |= SCC_HDLC_TX_BD_READY;

  return (OK);
} /* wdbPktTx */


/******************************************************************************
*
* wdbPktFree - free the input buffer
*
* This is the callback used to let us know the agent is done with the
* input buffer we loaded it.
*
* RETURNS: N/A
*/

static void wdbPktFree
    (
    void *	pDev
    )
    {
    SCC_HDLC_BD * pBD = ((WDB_HDLC_PKT_DEV*)pDev)->pBD;

    pBD->dataLength  = 0;
    pBD->statusMode &= SCC_HDLC_RX_BD_WRAP;
    pBD->statusMode |= (SCC_HDLC_RX_BD_EMPTY | SCC_HDLC_RX_BD_INT);

    }

/******************************************************************************
*
* wdbPktModeSet - switch driver modes
*
* RETURNS: OK for a supported mode, else ERROR
*/

static STATUS wdbPktModeSet
    (
    void *	pDev,
    uint_t	newMode
    )
    {
    WDB_HDLC_PKT_DEV * pPktDev = pDev;

    if (newMode == WDB_COMM_MODE_INT)
	pPktDev->wdbDrvIf.mode = WDB_COMM_MODE_INT;
    else if (newMode == WDB_COMM_MODE_POLL)
	pPktDev->wdbDrvIf.mode = WDB_COMM_MODE_POLL;
    else
	return (ERROR);

    return (OK);
    }

/******************************************************************************
*
* wdbPktPoll - poll for a packet
*
* This routine polls for a packet. If a packet has arrived it invokes
* the agents callback.
*
* RETURNS: OK if a packet has arrived, else ERROR.
*/

static STATUS wdbPktPoll
    (
    void *	pDev
    )
    {
    WDB_HDLC_PKT_DEV *	pPktDev = pDev;
    struct mbuf * 	pMbuf;

    return (ERROR);
    }



