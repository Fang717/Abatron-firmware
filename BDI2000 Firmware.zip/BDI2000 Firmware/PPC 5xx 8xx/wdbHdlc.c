/* wdbHdlc.c - WDB fast HDLC communication initialization library */

/* Copyright 2000 Abatron AG. */

/*
modification history
--------------------

01a,04feb00,rd   written
*/

/*
DESCRIPTION
Initializes the HDLC connection for the WDB agent.

NOMANUAL
*/

#include "wdbHdlcPktDrv.c"

#if     WDB_MTU > WDB_HDLC_PKT_MTU
#undef  WDB_MTU
#define WDB_MTU WDB_HDLC_PKT_MTU
#endif  /* WDB_MTU > WDB_HDLC_PKT_MTU */

/******************************************************************************
*
* wdbCommDevInit - initialize the HDLC connection
*/

STATUS wdbCommDevInit
    (
    WDB_COMM_IF *	pCommIf,
    char ** 		ppWdbInBuf,
    char **		ppWdbOutBuf
    )
    {
    static WDB_HDLC_PKT_DEV	wdbHdlcPktDev;
    static uint_t		wdbInBuf [WDB_MTU/4];
    static uint_t		wdbOutBuf [WDB_MTU/4];

    /* update input & output buffer pointers */
    *ppWdbInBuf  = (char *) wdbInBuf;
    *ppWdbOutBuf = (char *) wdbOutBuf;

    /* update communication interface mtu */
    wdbCommMtu = WDB_MTU;

    /* HDLC packet driver */
    wdbHdlcPktDevInit (&wdbHdlcPktDev, udpRcv);

    if (udpCommIfInit (pCommIf, &wdbHdlcPktDev.wdbDrvIf) == ERROR)
	return (ERROR);

    return (OK);
    }
