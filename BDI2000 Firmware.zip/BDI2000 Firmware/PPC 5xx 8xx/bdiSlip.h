/* wdbBdiPktDrv.h - header file for debug agents BDI packet driver */

/* Copyright 1995-1996 Abatron AG, Switzerland. */

/*
modification history
--------------------
09jan96/RD:  created.
*/

#ifndef __INCwdbFslipPktDrvh
#define __INCwdbFslipPktDrvh

/* includes */

#include "wdb/wdb.h"
#include "wdb/wdbCommIfLib.h"
#include "wdb/wdbMbufLib.h"

/* defines */

#define WDB_FSLIP_PKT_MTU	1500    /* MTU of this driver */

/* data types */

typedef struct		/* hidden */
    {
    WDB_DRV_IF	wdbDrvIf;	/* a packet dev must have this first   */
    u_int	currMode;	/* current mode    - poll or int       */
    } WDB_FSLIP_PKT_DEV;

/* function prototypes */

#if defined(__STDC__)

extern void	wdbFslipPktDevInit (WDB_FSLIP_PKT_DEV *pPktDev,
				    void             (*stackRcv)());

#else   /* __STDC__ */

extern void    wdbFslipPktDevInit ();

#endif  /* __STDC__ */

#endif  /* __INCwdbFslipPktDrvh */

