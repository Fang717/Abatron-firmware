/* wdbFslipPktDrv.c - debug agents fast SLIP packet driver */

/* Copyright 1998-1999 Abatron AG, Switzerland. */

/*
modification history
--------------------
01a,17jun99,rd:  created.
*/

/*************************************************************************
|  INCLUDES
|*************************************************************************/

#include "string.h"
#include "vxWorks.h"
#include "config.h"
#include "drv/multi/ppc860Siu.h"
#include "drv/multi/ppc860Cpm.h"
#include "drv/sio/ppc860Sio.h"
#include "mbx800.h"
#include "wdb/wdbMbufLib.h"
#include "wdbFslipPktDrv.h"


/*************************************************************************
|  DEFINES
|*************************************************************************/

/* SLIP special codes */
#define SLIP_END        0300
#define SLIP_ESC        0333
#define SLIP_ESC_END    0334
#define SLIP_ESC_ESC    0335

#define SMC_NUM                 2       /* the used SMC channel (1 or 2) */
#define BRG_NUM                 2       /* the used baudrate generator   */
#define SMC_BAUDRATE		260000	/* the baudrate to use */

#define SMC_RBD_NUM		2
#define SMC_TBD_NUM		2
#define SMC_RBD_OFF		0x400
#define SMC_TBD_OFF		(SMC_RBD_OFF + (SMC_RBD_NUM * 8))

#define SMC_RX_BUFF_SIZE        96      /* the size of a receive buffer  */
#define SMC_TX_BUFF_SIZE        96      /* the size of a transmit buffer */
#define SMC_RX_BUF_OFF		0x480
#define SMC_TX_BUF_OFF		(SMC_RX_BUF_OFF + (SMC_RBD_NUM * SMC_RX_BUFF_SIZE))


/*************************************************************************
|  MACROS
|*************************************************************************/

#define MIN min


/*************************************************************************
|  TYPEDEFS
|*************************************************************************/

typedef struct smc_chan {
  int                 clockRate;      /* CPU clock frequency (Hz) */
  int                 bgrNum;         /* number of BRG being used */
  VINT32 *            pBaud;          /* BRG registers */
  VINT32              regBase;        /* register/DPR base address */
  SMC_DEV             uart;           /* UART SMC device */
} SMC_CHAN;


typedef struct {
  BOOL		busy;				/* processing state */
  BOOL		escape;				/* escape state */
  u_char*	pNext;				/* where to store next char */
  u_char        data[WDB_FSLIP_PKT_MTU];	/* RPC frame buffer */
} RX_FRAME;

typedef struct {
  UINT32	length;				/* remaining bytes to send */
  u_char*	pNext;				/* where to read next char */
  u_char	data[2 * WDB_FSLIP_PKT_MTU];	/* SLIP coded TX frame */
} TX_FRAME;


/*************************************************************************
|  LOCALS
|*************************************************************************/

static SMC_CHAN	        smcChan;        /* info about the SMC channel */
static TX_FRAME         txFrame;
static RX_FRAME		rxFrame;


/* forward declarations */
static STATUS wdbPktPoll (void *pDev);
static STATUS wdbPktTx   (void *pDev, struct mbuf * pMbuf);
static STATUS wdbPktModeSet (void *pDev, uint_t newMode);
static void   wdbPktFree (void *pDev);


/*******************************************************************************
*
* smcInit - initialize the SMC
*/

static void smcInit(void)
{
  int           smc;			/* the SMC number being initialized */
  int           baud;			/* the baud rate generator being used */
  int           frame;
  UINT32        clockDivider;

  /* lock interrupts */
  int oldlevel = intLock ();

  smc  = SMC_NUM - 1;		/* get SMC number */
  baud = BRG_NUM - 1;		/* get BRG number */

  /* setup channel info */
  smcChan.clockRate      = SPLL_FREQ_REQUESTED;
  smcChan.regBase        = vxImmrGet();
  smcChan.bgrNum         = BRG_NUM;
  smcChan.uart.smcNum    = SMC_NUM;
  smcChan.uart.txBdNum   = SMC_TBD_NUM;
  smcChan.uart.rxBdNum   = SMC_RBD_NUM;
  smcChan.uart.txBdBase  = (SMC_BUF*)(MPC860_REGB_OFFSET + SMC_TBD_OFF);
  smcChan.uart.rxBdBase  = (SMC_BUF*)(MPC860_REGB_OFFSET + SMC_RBD_OFF);
  smcChan.uart.txBufBase = (u_char*)(MPC860_DPRAM_BASE(smcChan.regBase) + SMC_TX_BUF_OFF);
  smcChan.uart.rxBufBase = (u_char*)(MPC860_DPRAM_BASE(smcChan.regBase) + SMC_RX_BUF_OFF);
  smcChan.uart.txBufSize = SMC_TX_BUFF_SIZE;
  smcChan.uart.rxBufSize = SMC_RX_BUFF_SIZE;
  smcChan.uart.pSmc      = (SMC*) ((UINT32)PPC860_DPR_SMC1(MPC860_DPRAM_BASE(smcChan.regBase)) + (smc * 0x100));
  smcChan.uart.pSmcReg   = (SMC_REG*)((UINT32)MPC860_SMCMR1(smcChan.regBase) + (smc * 0x10));
  smcChan.uart.intMask   = CIMR_SMC1 >> smc;

  smcChan.uart.pSmcReg->smcm = 0;

  smcChan.pBaud = (UINT32*)((UINT32)MPC860_BRGC1(smcChan.regBase) + (baud * 4));

  /* select RS232 pins */
  *MPC860_PBPAR(smcChan.regBase) |= 0xC0 << (smc * 4);

  /* set it to normal operations */
  *MPC860_SDCR(smcChan.regBase) = SDCR_RAID_BR5;

  /* masks off this SMC's interrupt. */
  *CIMR(smcChan.regBase) &= (~smcChan.uart.intMask);

  /* set up SMC as NMSI, select Baud Rate Generator */
  switch( baud ) {
    default:	/* default to BRG1 */
    case 0:
      * SIMODE(smcChan.regBase) |= (SIMODE_SMC1CS_BRG1 << (16 * smc));
      break;
    case 1:
      * SIMODE(smcChan.regBase) |= (SIMODE_SMC1CS_BRG2 << (16 * smc));
      break;
    case 2:
      * SIMODE(smcChan.regBase) |= (SIMODE_SMC1CS_BRG3 << (16 * smc));
      break;
    case 3:
      * SIMODE(smcChan.regBase) |= (SIMODE_SMC1CS_BRG4 << (16 * smc));
      break;
  } /* switch */

  /* reset baud rate generator, wait for reset to clear... */
  *smcChan.pBaud |= BRGC_RST;
  while (*smcChan.pBaud & BRGC_RST);

  /* set baudrate */
  clockDivider   = ((smcChan.clockRate + (8L * SMC_BAUDRATE)) / (16L * SMC_BAUDRATE)) - 1;
  *smcChan.pBaud = (BRGC_CD_MSK & (clockDivider << 1)) | BRGC_EN;

  /* set up transmit buffer descriptors */
  smcChan.uart.txBdBase = (SMC_BUF*)(smcChan.regBase + ((UINT32)smcChan.uart.txBdBase ));
  smcChan.uart.pSmc->param.tbase = (UINT16)((UINT32)smcChan.uart.txBdBase);
  smcChan.uart.txBdNext = 0;

  /* initialize each transmit buffer descriptor */
  for (frame = 0; frame < smcChan.uart.txBdNum; frame++) {
    smcChan.uart.txBdBase[frame].statusMode  = BD_TX_INTERRUPT_BIT;
    smcChan.uart.txBdBase[frame].dataLength  = 0;
    smcChan.uart.txBdBase[frame].dataPointer = smcChan.uart.txBufBase + (frame * smcChan.uart.txBufSize);
  } /* for */

  /* set the last BD to wrap to the first */
  smcChan.uart.txBdBase[(frame - 1)].statusMode |= BD_TX_WRAP_BIT;

  /* set up receive buffer descriptors */
  smcChan.uart.rxBdBase = (SMC_BUF *) (smcChan.regBase + ((UINT32) smcChan.uart.rxBdBase ));
  smcChan.uart.pSmc->param.rbase = (UINT16) ((UINT32) smcChan.uart.rxBdBase);
  smcChan.uart.rxBdNext = 0;

  /* initialize each receive buffer descriptor */
  for (frame = 0; frame < smcChan.uart.rxBdNum; frame++) {
    smcChan.uart.rxBdBase[frame].statusMode  = BD_RX_EMPTY_BIT | BD_RX_INTERRUPT_BIT;
    smcChan.uart.rxBdBase[frame].dataLength  = smcChan.uart.rxBufSize;
    smcChan.uart.rxBdBase[frame].dataPointer = smcChan.uart.rxBufBase + (frame * smcChan.uart.rxBufSize);
  } /* for */

  /* set the last BD to wrap to the first */
  smcChan.uart.rxBdBase[(frame - 1)].statusMode |= BD_RX_WRAP_BIT;

  /* set SMC attributes to standard UART mode */
  smcChan.uart.pSmcReg->smcmr = SMCMR_STD_MODE;

  /* initialize parameter RAM area for this SMC */
  smcChan.uart.pSmc->param.rfcr   = 0x18;	/* supervisor data access */
  smcChan.uart.pSmc->param.tfcr   = 0x18;	/* supervisor data access */
  smcChan.uart.pSmc->param.mrblr  = smcChan.uart.rxBufSize;
  smcChan.uart.pSmc->param.maxidl = 0x5;	/* max. 5 char idle time */
  smcChan.uart.pSmc->param.brkec  = 0x0;	/* zero break condition ctr */
  smcChan.uart.pSmc->param.brkcr  = 0x1;	/* xmit 1 BRK on stop */

  /* execute INIT RX and TX PARAMS */
  while (*CPCR(smcChan.regBase) & CPM_CR_FLG);
  if (SMC_NUM == 1)
    *CPCR(smcChan.regBase) = CPM_CR_CHANNEL_SMC1 | CPM_CR_SMC_INIT_RT | CPM_CR_FLG;
  else
    *CPCR(smcChan.regBase) = CPM_CR_CHANNEL_SMC2 | CPM_CR_SMC_INIT_RT | CPM_CR_FLG;
  while (*CPCR(smcChan.regBase) & CPM_CR_FLG);

  /* clear all events */
  smcChan.uart.pSmcReg->smce = SMCE_ALL_EVENTS;

  /* enables the transmitter and receiver  */
  smcChan.uart.pSmcReg->smcmr |= SMCMR_TEN | SMCMR_REN;

  /* unmask interrupt (Tx, Rx only) */
  smcChan.uart.pSmcReg->smcm = SMCM_TX_MSK | SMCM_RX_MSK;
  *CIMR(smcChan.regBase) |= smcChan.uart.intMask;

  intUnlock (oldlevel);	/* UNLOCK INTERRUPTS */
} /* smcInit */


/*******************************************************************************
*
* smcInterrupt - handle an SMC interrupt
*
* This routine is called to handle SMC interrupts.
*/

static void smcInterrupt(WDB_FSLIP_PKT_DEV *pPktDev)
{
  UINT8         smcEvent;
  UINT16        rxCount;
  FAST char*	pChar;
  FAST char     rxChar;
  SMC_BUF*      pBD;


  /* read and clear events */
  smcEvent = smcChan.uart.pSmcReg->smce;
  smcChan.uart.pSmcReg->smce = smcEvent;

  /* handle receive event */
  if (smcEvent & SMCE_RX) {

    /* process all filled receive buffers */
    pBD = smcChan.uart.rxBdBase + smcChan.uart.rxBdNext;
    while (!(pBD->statusMode & BD_RX_EMPTY_BIT)) {

      /* append to frame buffer */
      if (!rxFrame.busy) {
        rxCount = pBD->dataLength;
        pChar   = pBD->dataPointer;
        while (rxCount--) {
          rxChar = *pChar++;

          if (rxChar == SLIP_END) {
            if (rxFrame.pNext > rxFrame.data) {
              struct mbuf* pMbuf = wdbMbufAlloc();;
              if (pMbuf) {
                wdbMbufClusterInit (pMbuf,
                                    rxFrame.data,
                                    rxFrame.pNext - rxFrame.data,
				    (int (*)())wdbPktFree,
                                    (int)pPktDev);
	        (*pPktDev->wdbDrvIf.stackRcv) (pMbuf);  /* invoke callback */
                rxFrame.busy = TRUE;
              } /* if */
              else {
                rxFrame.busy   = FALSE;
                rxFrame.escape = FALSE;
                rxFrame.pNext  = rxFrame.data;
              } /* else */
              break;
            } /* if */
          } /* if */

          else if (rxChar == SLIP_ESC) {
            rxFrame.escape = TRUE;
          } /* else if */

          else {
            if (rxFrame.escape) {
              rxFrame.escape = FALSE;
              if      (rxChar == SLIP_ESC_END) *rxFrame.pNext++ = SLIP_END;
              else if (rxChar == SLIP_ESC_ESC) *rxFrame.pNext++ = SLIP_ESC;
            } /* if */
            else {
              *rxFrame.pNext++ = rxChar;
            } /* else */
          } /* else */

        } /* while */
      } /* if */

      /* switch to next buffer */
      pBD->statusMode |= BD_RX_EMPTY_BIT;
      smcChan.uart.rxBdNext = (smcChan.uart.rxBdNext + 1) % smcChan.uart.rxBdNum;
      pBD = smcChan.uart.rxBdBase + smcChan.uart.rxBdNext;

    } /* while */
  } /* if */

  /* handle transmit event */
  if ((smcEvent & SMCE_TX) && (txFrame.length > 0)) {

    /* process all empty transmit buffers */
    pBD = smcChan.uart.txBdBase + smcChan.uart.txBdNext;
    while (!(pBD->statusMode & BD_TX_READY_BIT) && (txFrame.length > 0)) {

      pBD->dataLength = 0;
      pChar = pBD->dataPointer;
      while ((pBD->dataLength < smcChan.uart.txBufSize) && (txFrame.length > 0)) {
        *pChar++ = *txFrame.pNext++;
        pBD->dataLength++;
        txFrame.length--;
      } /* while */

      /* switch to next buffer */
      pBD->statusMode |= BD_TX_READY_BIT;
      smcChan.uart.txBdNext = (smcChan.uart.txBdNext + 1) % smcChan.uart.txBdNum;
      pBD = smcChan.uart.txBdBase + smcChan.uart.txBdNext;

    } /* while */
  } /* if */

  /* clear in service bit */
  *CISR(smcChan.regBase) = smcChan.uart.intMask;
} /* smcInterrupt */


/*******************************************************************************
*
* wdbFslipPktDevInit - init the fast SLIP paket driver
*
* This routine init the WDB agents paket driver.
*
* RETURNS: initialized WDB_SLIP_PKT_DEV structure
*
*/
void wdbFslipPktDevInit
    (
    WDB_FSLIP_PKT_DEV *pPktDev,
    void             (*stackRcv)()
    )
    {

    /* setup driver interface structure */
    pPktDev->wdbDrvIf.mode       = WDB_COMM_MODE_INT;
    pPktDev->wdbDrvIf.mtu        = WDB_FSLIP_PKT_MTU;
    pPktDev->wdbDrvIf.stackRcv	 = stackRcv;
    pPktDev->wdbDrvIf.devId	 = (WDB_FSLIP_PKT_DEV *)pPktDev;
    pPktDev->wdbDrvIf.pollRtn	 = wdbPktPoll;
    pPktDev->wdbDrvIf.pktTxRtn	 = wdbPktTx;
    pPktDev->wdbDrvIf.modeSetRtn = wdbPktModeSet;

    /* init receive frame */
    rxFrame.busy   = FALSE;
    rxFrame.escape = FALSE;
    rxFrame.pNext  = rxFrame.data;

    /* init transmit frame */
    txFrame.length = 0;
    txFrame.pNext  = txFrame.data;

    /* init SMC channel in CPM */
    smcInit();

    /* connect interrupt service */
    if (SMC_NUM == 1)
      (void)intConnect (IV_SMC1, (VOIDFUNCPTR) smcInterrupt, (int)pPktDev);
    else
      (void)intConnect (IV_SMC2_PIP, (VOIDFUNCPTR) smcInterrupt, (int)pPktDev);

    } /* wdbFslipPktDevInit */


/******************************************************************************
*
* wdbPktTx - transmit a packet
*
* This routine can only be called by the WDB agent.
*
* RETURNS: OK, or ERROR if a packet is currently being transmitted, or
* the packet is too large to send.
*/

static STATUS wdbPktTx
    (
    void * pDev,
    struct mbuf * pMbuf
    )
{
  int		pktSize;
  u_char        txChar;
  SMC_BUF*      pTxBD;
  u_char*       pPkt;
  u_char*       pBuf;

  static u_char pktBuf[WDB_FSLIP_PKT_MTU];

  /* check if buffer free */
  if (txFrame.length > 0) return (ERROR);

  /* copy transmit data to local buffer */
  wdbMbufDataGet(pMbuf, pktBuf, WDB_FSLIP_PKT_MTU, &pktSize);
  wdbMbufChainFree(pMbuf);

  /* build SLIP frame */
  pPkt = pktBuf;
  pBuf = txFrame.data;
  while (pktSize--) {
    txChar = *pPkt++;
    if (txChar == SLIP_END) {
      *pBuf++ = SLIP_ESC;
      *pBuf++ = SLIP_ESC_END;
    } /* if */
    else if (txChar == SLIP_ESC) {
      *pBuf++ = SLIP_ESC;
      *pBuf++ = SLIP_ESC_ESC;
    } /* else if */
    else {
      *pBuf++ = txChar;
    } /* else */
  } /* while */
  *pBuf++ = SLIP_END;  /* mark end of frame */
  txFrame.length = pBuf - txFrame.data;
  txFrame.pNext  = txFrame.data;

  /* start transmitting (send SLIP_END) */
  pTxBD = smcChan.uart.txBdBase + smcChan.uart.txBdNext;
  if (pTxBD->statusMode & BD_TX_READY_BIT) return (ERROR);
  *pTxBD->dataPointer = SLIP_END;
  pTxBD->dataLength   = 1;
  smcChan.uart.txBdNext = (smcChan.uart.txBdNext + 1) % smcChan.uart.txBdNum;
  pTxBD->statusMode  |= BD_TX_READY_BIT;

  return (OK);
} /* wdbPktTx */


/******************************************************************************
*
* wdbPktFree - free the input buffer
*
* This is the callback used to let us know the agent is done with the
* input buffer we loaded it.
*
* RETURNS: N/A
*/

static void wdbPktFree
    (
    void *	pDev
    )
    {

    rxFrame.busy   = FALSE;
    rxFrame.escape = FALSE;
    rxFrame.pNext  = rxFrame.data;

    }

/******************************************************************************
*
* wdbPktModeSet - switch driver modes
*
* RETURNS: OK for a supported mode, else ERROR
*/

static STATUS wdbPktModeSet
    (
    void *	pDev,
    uint_t	newMode
    )
    {
    WDB_FSLIP_PKT_DEV * pPktDev = pDev;

    if (newMode == WDB_COMM_MODE_INT)
	pPktDev->wdbDrvIf.mode = WDB_COMM_MODE_INT;
    else if (newMode == WDB_COMM_MODE_POLL)
	return (ERROR);
    else
	return (ERROR);

    return (OK);
    }

/******************************************************************************
*
* wdbPktPoll - poll for a packet
*
* This routine polls for a packet. If a packet has arrived it invokes
* the agents callback.
*
* RETURNS: OK if a packet has arrived, else ERROR.
*/

static STATUS wdbPktPoll
    (
    void *	pDev
    )
    {
    WDB_FSLIP_PKT_DEV *	pPktDev = pDev;
    struct mbuf * 	pMbuf;

    return (ERROR);
    }



