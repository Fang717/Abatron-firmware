/* wdbBdiPktDrv.c - debug agents BDI packet driver */

/* Copyright 1995-1996 Abatron AG, Switzerland. */

/*
modification history
--------------------
01a,09jan96,rd:  created.
*/

/* includes */

#include "string.h"
#include "vxWorks.h"
#include "semLib.h"
#include "taskLib.h"
#include "wdb/wdbMbufLib.h"
#include "wdbBdiPktDrv.h"

IMPORT void	bdiInit (void* baseAddr);
IMPORT void	bdiCall (void);

/* defines */

#define	IDLE_PRI		255	/* priority of the idle   task */
#define	WAKEUP_PRI		3	/* priority of the wakeup task */
#define WAKEUP_TASK_POLL_DELAY	20	/* receive poll delay in system ticks */

#define MIN min

/* typedefs */

typedef struct
    {
    u_short	recvCount;	/* number of bytes in the receive buffer */
    u_short	sendCount;	/* number of bytes in the send buffer    */
    u_int*	pRecvBuffer;	/* pointer to the receive buffer         */
    u_int*	pSendBuffer;	/* pointer to the send buffer            */
    } BDI_COMM_INFO;


/* globals */


/* locals */

static BDI_COMM_INFO	bdiCommInfo;
static u_int		recvBuffer[WDB_BDI_PKT_MTU/4];
static u_int		sendBuffer[WDB_BDI_PKT_MTU/4];

static int		taskIdleId;	/* task ID of idel   task  */
static int		taskWakeupId;	/* task ID of wakeup task  */
static SEM_ID		semWakeupId;	/* the wakeup semaphore ID */

/* forward declarations */

static STATUS wdbBdiPoll (void *pDev);
static STATUS wdbBdiTx   (void *pDev, struct mbuf * pMbuf);
static STATUS wdbBdiModeSet (void *pDev, uint_t newMode);
static void   wdbBdiFree (void *pDev);


/*******************************************************************************
*
* taskWakeup - wakeup task for the target agent
*
* This tasks waits with timeout at the wakeup semaphore. When the semaphore is
* set or after a timeout, The receive buffer is checked an pending data sent
* to the debug agent.
*/

LOCAL void taskWakeup(void *pDev) 
    {
    WDB_BDI_PKT_DEV *	pPktDev = pDev;
    struct mbuf * 	pMbuf;

    FOREVER
	{
	semTake (semWakeupId, WAKEUP_TASK_POLL_DELAY);
	if ((bdiCommInfo.recvCount) && (pPktDev->wdbDrvIf.mode == WDB_COMM_MODE_INT))
	    {
	    /*
	     * Fill the input buffer with the packet. Use an mbuf cluster to pass
	     * the packet on to the agent.
	     */
	    pMbuf = wdbMbufAlloc();
	    if (pMbuf == NULL)
		{
		/* reset receive buffer */
		bdiCommInfo.recvCount = 0;
		continue;
		}

	    wdbMbufClusterInit (pMbuf, recvBuffer, bdiCommInfo.recvCount, \
				(int (*)())wdbBdiFree, (int)pPktDev);

	    (*pPktDev->wdbDrvIf.stackRcv) (pMbuf);  /* invoke callback */

	    } /* if (bdiCommInfo.recvCount) */
	} /* FOREVER */
    } /* taskWakeup */


/*******************************************************************************
*
* taskIdle - idle task to speed up recognition of pending receive data
*
* This tasks polls the receive buffer and signals a new receive data block
* by setting a binary semaphor.
*
*/

LOCAL void taskIdle(void) 
    {
    FOREVER
	{
	if (bdiCommInfo.recvCount) semGive (semWakeupId);		
	} /* FOREVER */
    } /* taskIdle */


/*******************************************************************************
*
* wdbBdiPktDevInit - init the BDI paket driver
*
* This routine init the WDB agents paket driver using the BDI interface.
*
* RETURNS: initialized WDB_BDI_PKT_DEV structure
*
*/
void wdbBdiPktDevInit 
    (
    WDB_BDI_PKT_DEV *pPktDev,
    void           (*stackRcv)()
    )
    {

    /* setup driver interface structure */
    pPktDev->wdbDrvIf.mode       = (WDB_COMM_MODE_POLL | WDB_COMM_MODE_INT);
    pPktDev->wdbDrvIf.mtu        = WDB_BDI_PKT_MTU;
    pPktDev->wdbDrvIf.stackRcv	 = stackRcv;
    pPktDev->wdbDrvIf.devId	 = (WDB_BDI_PKT_DEV *)pPktDev;
    pPktDev->wdbDrvIf.pollRtn	 = wdbBdiPoll;
    pPktDev->wdbDrvIf.pktTxRtn	 = wdbBdiTx;
    pPktDev->wdbDrvIf.modeSetRtn = wdbBdiModeSet;

    /* init the communication info */
    bdiCommInfo.recvCount   = 0;
    bdiCommInfo.sendCount   = 0;
    bdiCommInfo.pRecvBuffer = recvBuffer;
    bdiCommInfo.pSendBuffer = sendBuffer;

    /* create wakeup system, semaphore and wakeup task */
    semWakeupId  = semBCreate (SEM_Q_FIFO, SEM_EMPTY);

    taskIdleId   = taskSpawn (	"tBdiIdle", 
				IDLE_PRI,
				VX_UNBREAKABLE,
				1000, 
				(FUNCPTR) taskIdle,
				0,0,0,0,0,0,0,0,0,0);

    taskWakeupId = taskSpawn (	"tBdiWakeup", 
				WAKEUP_PRI,
				VX_UNBREAKABLE,
				1000, 
				(FUNCPTR) taskWakeup,
				(int)pPktDev,0,0,0,0,0,0,0,0,0);

    /* tell the BDI where the communication structure is */
    bdiInit(&bdiCommInfo);

    pPktDev->wdbDrvIf.mode = WDB_COMM_MODE_INT;

    } /* wdbBdiPktDevInit */


/******************************************************************************
*
* wdbBdiTx - transmit a packet.
*
* The packet is realy a chain of mbufs. We may have to just queue up
* this packet is we are already transmitting.
*
* RETURNS: OK or ERROR
*/

static STATUS wdbBdiTx
    (
    void *		pDev,
    struct mbuf * 	pMbuf
    )
    {
    int		packetSize;
    
    /* wait for empty transmit buffer */
    while (bdiCommInfo.sendCount) 
	{
	} /* while */

    /* copy transmit data to buffer */
    wdbMbufDataGet(pMbuf, (char*)sendBuffer, WDB_BDI_PKT_MTU, &packetSize);
    bdiCommInfo.sendCount = packetSize;
    wdbMbufChainFree (pMbuf);

    /* enter debug mode and wait for empty transmit buffer */
    while (bdiCommInfo.sendCount) 
	{
	bdiCall();
	} /* while */

    return (OK);
    }

/******************************************************************************
*
* wdbBdiFree - free the input buffer
*
* This is the callback used to let us know the agent is done with the
* input buffer we loaded it.
*
* RETURNS: N/A
*/

static void wdbBdiFree
    (
    void *	pDev
    )
    {
    bdiCommInfo.recvCount = 0;
    }

/******************************************************************************
*
* wdbBdiModeSet - switch driver modes
*
* RETURNS: OK for a supported mode, else ERROR
*/

static STATUS wdbBdiModeSet
    (
    void *	pDev,
    uint_t	newMode
    )
    {
    WDB_BDI_PKT_DEV * pPktDev = pDev;

    bdiCommInfo.recvCount = 0;

    if (newMode == WDB_COMM_MODE_INT)
	pPktDev->wdbDrvIf.mode = WDB_COMM_MODE_INT;
    else if (newMode == WDB_COMM_MODE_POLL)
	pPktDev->wdbDrvIf.mode = WDB_COMM_MODE_POLL;
    else
	return (ERROR);

    return (OK);
    }

/******************************************************************************
*
* wdbBdiPoll - poll for a packet
*
* This routine polls for a packet. If a packet has arrived it invokes
* the agents callback.
*
* RETURNS: OK if a packet has arrived, else ERROR.
*/ 

static STATUS wdbBdiPoll
    (
    void *	pDev
    )
    {
    WDB_BDI_PKT_DEV *	pPktDev = pDev;
    struct mbuf * 	pMbuf;

    if (bdiCommInfo.recvCount)
	{
	/*
	 * Fill the input buffer with the packet. Use an mbuf cluster to pass
	 * the packet on to the agent.
	 */
	pMbuf = wdbMbufAlloc();
	if (pMbuf == NULL)
	    {
	    /* reset receive buffer */
	    bdiCommInfo.recvCount = 0;
	    return (ERROR);
	    }

	wdbMbufClusterInit (pMbuf, recvBuffer, bdiCommInfo.recvCount, \
			(int (*)())wdbBdiFree, (int)pPktDev);

	(*pPktDev->wdbDrvIf.stackRcv) (pMbuf);  /* invoke callback */

	return (OK);
	}

    return (ERROR);
    }



