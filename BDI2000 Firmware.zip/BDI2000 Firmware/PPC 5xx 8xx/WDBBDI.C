/* wdbBdi.c - WDB BDI communication initialization library */

/* Copyright 1999Abatron AG. */

/*
modification history
--------------------

01a,28jan99,rd   written
*/

/*
DESCRIPTION
Initializes the BDI connection for the WDB agent.

NOMANUAL
*/

#include "wdbBdiPktDrv.c"

#if     WDB_MTU > WDB_BDI_PKT_MTU
#undef  WDB_MTU
#define WDB_MTU WDB_BDI_PKT_MTU
#endif  /* WDB_MTU > WDB_BDI_PKT_MTU */

/******************************************************************************
*
* wdbCommDevInit - initialize the netrom connection
*/

STATUS wdbCommDevInit
    (
    WDB_COMM_IF *	pCommIf,
    char ** 		ppWdbInBuf,
    char **		ppWdbOutBuf
    )
    {
    static WDB_BDI_PKT_DEV	wdbBdiPktDev;	/* BDI packet device */
    static uint_t		wdbInBuf [WDB_MTU/4];
    static uint_t		wdbOutBuf [WDB_MTU/4];

    /* update input & output buffer pointers */
    *ppWdbInBuf  = (char *) wdbInBuf;
    *ppWdbOutBuf = (char *) wdbOutBuf;

    /* update communication interface mtu */
    wdbCommMtu = WDB_MTU;

    /*BDI packet driver - supports task or external agent */
    wdbBdiPktDevInit (&wdbBdiPktDev, udpRcv);

    if (udpCommIfInit (pCommIf, &wdbBdiPktDev.wdbDrvIf) == ERROR)
	return (ERROR);

    return (OK);
    }
